-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 31, 2022 lúc 05:12 PM
-- Phiên bản máy phục vụ: 10.4.24-MariaDB
-- Phiên bản PHP: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `ecom_store`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `admin_image` text NOT NULL,
  `admin_country` text NOT NULL,
  `admin_about` text NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_job` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_image`, `admin_country`, `admin_about`, `admin_contact`, `admin_job`) VALUES
(1, 'Benzema', 'benzema@gmail.com', '123456', 'image.webp', 'France', 'Cau Thu cua Realmadrid', '968048046', 'Cau Thu'),
(3, 'Ronaldo', 'Ronaldo@gmail.com', '123456', '21add8f2050c802eb03427164848c899.jpg', 'Bo Dao Nha', 'Cau Thu', '123-456-789', 'Cau Thu Bong Da');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `boxes_section`
--

CREATE TABLE `boxes_section` (
  `box_id` int(11) NOT NULL,
  `box_title` text NOT NULL,
  `box_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `boxes_section`
--

INSERT INTO `boxes_section` (`box_id`, `box_title`, `box_desc`) VALUES
(1, 'Sản Phẩm Tốt Nhất', 'Chúng tôi luôn bán những sản phẩm đẹp, hiện đại và chất lượng'),
(2, 'Phục Vụ Chu Đáo', 'Phục vụ khách hàng là niềm vinh dự của chúng tôi'),
(3, 'Miễn Phí Giao Hàng', 'Miễn phí giao hàng trên toàn quốc khi mua 2 sản phẩm trở lên');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `p_id` int(11) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `size` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_desc`) VALUES
(1, 'Nam giới', ''),
(2, 'Nữ Giới', ''),
(3, 'Trẻ em', ''),
(4, 'Đối tượng khác', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_pass` varchar(255) NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_image` text NOT NULL,
  `customer_ip` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_contact`, `customer_address`, `customer_image`, `customer_ip`) VALUES
(10, 'Tong Duc Nam', 'nam23@gmail.com', '123456', '968048046', 'Afghanistan', '8081e2a90695d2f6711e250084dd1024.jpg', '::1'),
(11, 'Tong Van A', 'tongvana@gmail.com', '123456', '968048046', 'Việt Nam', '15726370_1690341521205005_2559776209906429212_n.PSD.png', '::1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer_orders`
--

CREATE TABLE `customer_orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `size` text NOT NULL,
  `order_date` date NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `customer_orders`
--

INSERT INTO `customer_orders` (`order_id`, `customer_id`, `due_amount`, `invoice_no`, `qty`, `size`, `order_date`, `order_status`) VALUES
(1, 11, 100000, 162601059, 1, 'Vừa', '2022-05-15', 'Complete'),
(2, 11, 50000, 162601059, 1, 'Lớn', '2022-05-15', 'Complete'),
(3, 10, 30000, 1420673869, 1, 'Vừa', '2022-05-22', 'Complete'),
(4, 10, 40000, 1669242987, 1, 'Vừa', '2022-05-30', 'Pending');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_code` text NOT NULL,
  `payment_mode` text NOT NULL,
  `payment_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `payments`
--

INSERT INTO `payments` (`payment_id`, `invoice_no`, `amount`, `payment_code`, `payment_mode`, `payment_date`) VALUES
(3, 1420673869, 30000, '1111', 'Mobile Banking', '30/5/2022');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pending_orders`
--

CREATE TABLE `pending_orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `product_id` text NOT NULL,
  `qty` int(11) NOT NULL,
  `size` text NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `pending_orders`
--

INSERT INTO `pending_orders` (`order_id`, `customer_id`, `invoice_no`, `product_id`, `qty`, `size`, `order_status`) VALUES
(2, 11, 162601059, '8', 1, 'Lớn', 'Complete'),
(4, 10, 1669242987, '1', 1, 'Vừa', 'Pending');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `p_cat_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_keywords` text NOT NULL,
  `product_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`product_id`, `p_cat_id`, `cat_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_keywords`, `product_desc`) VALUES
(1, 8, 1, '2022-05-30 10:08:18', 'Áo Khoác dài nam', '8d39f6af4ce146948f5875362d5b93f3.jpg', 'afd6466a4745e06ee58dabe6ae7d9829.jpg', '9fe1bd74972bc5796c07b50c9b7195a6.jpg', 40000, 'adult', '<p>Thời Trang hiện đại</p>'),
(3, 9, 1, '2022-05-30 10:08:47', 'Áo Thun nam', '9c5dc48a27a8777aceeab8123ea08403.jpg', 'c9d7423fafeecc43bd80edd7e5ba5df9.jpg', 'b18a9339c24b2a276dba4cf9bc08e6e2.jpg', 40000, 'adult', '<p>&Aacute;o Thun Nam rộng c&aacute; t&iacute;nh</p>'),
(4, 8, 3, '2022-05-30 10:09:19', 'Áo rét trẻ em', 'e12d130f8b07d8afc0f418d3947dd86a.jpg', 'bec9df8e3c749f5a6428e766d1d5dd36.jpg', 'fb90d47e81e5111c7c3edb898c083252.jpg', 50000, 'Kids', '<p>&Aacute;o r&eacute;t d&agrave;nh cho trẻ em</p>'),
(5, 9, 2, '2022-05-14 08:52:43', 'Áo Thun Nữ', '8.jpg', '6.jpg', '7.jpg', 30000, 'adult', '<p>&Aacute;o Thun Nữ</p>'),
(6, 8, 2, '2022-05-14 08:58:35', 'Áo khoác nữ', 'ba7dd6db2e4750b4bf8abd8345d9a4a5.jpg', 'ea0316df334b80b9768f7ce79c628361.jpg', 'd5e4e5bc59f095575493055093cb48b2.jpg', 20000, 'adult', '<p>&Aacute;o Kho&aacute;c Thun Nữ</p>'),
(8, 8, 1, '2022-05-14 09:02:56', 'Áo Sơ Mi Nam', '2.jpg', '4.jpg', '3.jpg', 50000, 'adult', '<p>&Aacute;o sơ mi nam nữ d&agrave;i tay Unisex Basic m&agrave;u trắng v&agrave; đen sơ mi lụa học sinh mịn m&aacute;t form rộng su&ocirc;ng</p>'),
(10, 8, 1, '2022-05-30 10:42:30', 'Quần Áo Thu Đông Nam', 'c5d1854f079159d305842be34fc5ac55.jfif', 'bdca64e0b08edc54d9869a5e365b0197.jfif', '866f6708f7fdd08a095f70ccdd4c0051.jfif', 1000000, 'adult', '<p>Bộ Quần &Aacute;o Thu Đ&ocirc;ng Nam &Aacute;o Hoodies D&agrave;i Tay Kết Hợp Quần T&uacute;i Hộp Trẻ Trung AO TOP 126 + JOGGER</p>');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product_categories`
--

CREATE TABLE `product_categories` (
  `p_cat_id` int(11) NOT NULL,
  `p_cat_title` text NOT NULL,
  `p_cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `product_categories`
--

INSERT INTO `product_categories` (`p_cat_id`, `p_cat_title`, `p_cat_desc`) VALUES
(1, 'Áo Đôi', 'Áo Đôi Thời Trang Tinh Tế'),
(2, 'Áo Nỉ OverSize', 'Thoải mái cá tính'),
(3, 'Váy', 'Dập ly nữ tính, thanh lịch'),
(8, 'Quần áo thu đông', 'Bộ quần áo nhẹ, khóa kéo phối mầu thanh lịch'),
(9, 'Áo Thun', 'Áo Thun T-shirt Trơn, Chất Liệu Cotton 4 Chiều');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slider`
--

CREATE TABLE `slider` (
  `slider_id` int(11) NOT NULL,
  `slider_name` varchar(255) NOT NULL,
  `slider_image` text NOT NULL,
  `slider_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `slider`
--

INSERT INTO `slider` (`slider_id`, `slider_name`, `slider_image`, `slider_url`) VALUES
(7, 'Slider Shoes', 'Fellmonger-banner-op.webp', 'http://localhost/ecommerce/ecommerce-master/M-Dev-Store/shop.php?p_cat=3'),
(8, 'Slider Jacket', 'jacket.jpg', 'http://localhost/ecommerce/ecommerce-master/M-Dev-Store/shop.php?p_cat=1'),
(9, 'Slider Accessories', 'women-accessories-banner_aa1a2d62-8764-4e2f-bfb4-6a40f14aa375.webp', 'http://localhost/ecommerce/ecommerce-master/M-Dev-Store/shop.php?p_cat=2'),
(10, 'Slider Coat', 'top-banner-coats.webp', 'http://localhost/ecommerce/ecommerce-master/M-Dev-Store/shop.php?p_cat=8');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Chỉ mục cho bảng `boxes_section`
--
ALTER TABLE `boxes_section`
  ADD PRIMARY KEY (`box_id`);

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`p_id`);

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Chỉ mục cho bảng `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Chỉ mục cho bảng `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Chỉ mục cho bảng `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Chỉ mục cho bảng `pending_orders`
--
ALTER TABLE `pending_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Chỉ mục cho bảng `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`p_cat_id`);

--
-- Chỉ mục cho bảng `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `boxes_section`
--
ALTER TABLE `boxes_section`
  MODIFY `box_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `pending_orders`
--
ALTER TABLE `pending_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT cho bảng `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `p_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `slider`
--
ALTER TABLE `slider`
  MODIFY `slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
