<?php
    $active = 'account';
    include ('includes/header.php');
?>

   <div id="content"><!-- content begin -->
       <div class="container"><!-- container begin -->
           <div class="col-sm-12"><!--col-md-12  begin -->
                <ul class="breadcrumb"><!-- breadcrumb begin -->
                    <li>
                        <a href="index.php">Trang Chủ</a>
                    </li>
                    <li>
                        Đăng Ký
                    </li>
                </ul>
           </div><!-- col-md-12  Finish -->
           <div class="col-md-3"> <!-- col-md-3 begin -->            
            <?php
                include("includes/sidebar.php");
            ?>
           </div><!-- col-md-3 finish -->
        <div class="col-md-9"> <!-- col-md-9 begin --> 
            <div class="box">

                <div class="box-header">
                    <center>
                        <h2>Đăng Ký Tài Khoản Mới</h2>
                    </center>
                    <form action="customer_register.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Họ và tên</label>
                            <input type="text" class="form-control" name="c_name" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" name="c_email" required>
                        </div>
                        <div class="form-group">
                            <label>Mật khẩu</label>
                            <input type="password" class="form-control" name="c_pass" required>
                        </div>
                        <div class="form-group">
                            <label>Số điện thoại</label>
                            <input type="text" class="form-control" name="c_contact" required>
                        </div>
                        <div class="form-group">
                            <label>Địa chỉ</label>
                            <input type="text" class="form-control" name="c_address" required>
                        </div>

                        <div class="form-group">
                            <label>Ảnh cá nhân</label>
                            <input type="file" class="form-control form-height-custom" name="c_image" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary" name="register">
                                <i class="fa fa-user-md"></i> Đăng ký
                            </button>
                        </div>
                    </form>
                </div>

            </div>
        </div> <!-- col-md-9 finish --> 
       </div><!-- container Finish -->

</div><!-- content Finish -->

<?php
     include("includes/footer.php");
 ?>
 <script src="js/jquery-331.min.js"></script>
 <script src="js/bootstrap-337.min.js"></script>
</body>
</html>

<?php
    if(isset($_POST['register']))
    {
        $c_name = $_POST['c_name']; //

        $c_email = $_POST['c_email'];

        $c_pass = $_POST['c_pass'];

        $c_contact = $_POST['c_contact'];

        $c_address = $_POST['c_address'];

        $c_image = $_FILES['c_image']['name'];

        $c_image_tmp = $_FILES['c_image']['tmp_name'];

        $c_ip = getRealIpUser();

        move_uploaded_file($c_image_tmp,"customer/customer_image/$c_image");

        $insert_customer = "insert into customers
        (customer_name,customer_email,customer_pass,customer_contact,customer_address,customer_image,customer_ip) values 
        ('$c_name','$c_email','$c_pass','$c_contact','$c_address','$c_image','$c_ip')";
        
        $run_customer = mysqli_query($con,$insert_customer);

        $sel_cart = "select * from cart where ip_add = '$c_ip'";

        $run_cart = mysqli_query($con,$sel_cart);

        $check_cart = mysqli_num_rows($run_cart);

        if($check_cart>0)
        {
            $_SESSION['customer_email'] = $c_email;

            echo "<script> alert('You have been Registered Successfully')</script>";
            
            echo "<script> window.open('checkout.php','_self')</script>";
        }else{
            $_SESSION['customer_email'] = $c_email;

            echo "<script> alert('You have been Registered Successfully')</script>";

            echo "<script>window.open('index.php','_self')</script>";
        }


    }
?>