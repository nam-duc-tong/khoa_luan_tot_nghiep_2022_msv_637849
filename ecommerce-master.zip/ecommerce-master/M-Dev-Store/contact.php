<?php
    $active='contact';
    include('includes/header.php');
?>

   <div id="content"><!-- content begin -->
       <div class="container"><!-- container begin -->
           <div class="col-sm-12"><!--col-md-12  begin -->
                <ul class="breadcrumb"><!-- breadcrumb begin -->
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        Contact Us
                    </li>
                </ul>
           </div><!-- col-md-12  Finish -->
           <div class="col-md-3"> <!-- col-md-3 begin -->            
            <?php
                include("includes/sidebar.php");
            ?>
           </div><!-- col-md-3 finish -->
        <div class="col-md-9"> <!-- col-md-9 begin --> 
            <div class="box">

                <div class="box-header">
                    <center>
                        <h2>Feel Free To Contact Us</h2>
                        <p class="text-muted">
                            If you have any question, feel free to contact us, Our Customer Service work <strong>24/7</strong>
                        </p>
                    </center>
                    <form action="contact.php" method="post">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Subject</label>
                            <input type="text" class="form-control" name="subject" required>
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea name="message" class="form-control"></textarea>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary" name="submit">
                                <i class="fa fa-user-md"></i>   Send Message
                            </button>
                        </div>
                    </form>
                    <?php
                        if(isset($_POST['submit']))
                        {
                            $sender_name = $_POST['name'];

                            $sender_email = $_POST['email'];

                            $sender_subject = $_POST['subject'];

                            $sender_message = $_POST['message'];

                            $receiver_email = "nam2382000@gmail.com";

                            mail($receiver_email,$sender_name,$sender_subject,$sender_message,$sender_email);
                            
                            $email = $_POST['email'];

                            $subject = "Welcome to my website";

                            $msg = "Thank for sending us message. ASAP We will reply your message";
                            
                            $from = "nam2382000@gmail.com";

                            mail($email,$subject,$msg,$from);

                            echo "<h2> Your message has sent successfully</h2>";
                            
                        }
                    ?>
                </div>
            </div>
        </div> <!-- col-md-9 finish --> 
       </div><!-- container Finish -->

</div><!-- content Finish -->

<?php
     include("includes/footer.php");
 ?>
 <script src="js/jquery-331.min.js"></script>
 <script src="js/bootstrap-337.min.js"></script>
</body>
</html>