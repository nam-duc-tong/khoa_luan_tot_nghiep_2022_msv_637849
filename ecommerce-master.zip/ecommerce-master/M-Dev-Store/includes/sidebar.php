<div class="panel panel-default sidebar-menu"><!-- panel panel-default sidebar-menu begin -->
    <div class="panel-heading"><!--panel-heading  begin -->
        <h3 class="panel-title"> <!--panel-title  begin -->
            Danh Mục Sản Phẩm
        </h3><!-- panel-title Finish -->
    </div><!-- panel-heading Finish -->

    <div class="panel-body"> <!--panel-body  begin -->
        <ul class="nav nav-pills nav-stacked category-menu"> <!--nav nav-pills nav-stacked category-menu  begin -->
            <!-- <li><a href="#">Jackets</a></li>
            <li><a href="#">Accessories</a></li>
            <li><a href="#">Shoes</a></li>
            <li><a href="#">Coats</a></li>
            <li><a href="#">T-Shirt</a></li> -->

            <?php
                getPCats();
            ?>
        </ul><!-- nav nav-pills nav-stacked category-menu Finish -->
    </div><!-- panel-body Finish -->
</div><!-- panel panel-default sidebar-menu Finish -->
<div class="panel panel-default sidebar-menu"><!-- panel panel-default sidebar-menu begin -->
    <div class="panel-heading"><!--panel-heading  begin -->
        <h3 class="panel-title"> <!--panel-title  begin -->
            Loại Sản Phẩm
        </h3><!-- panel-title Finish -->
    </div><!-- panel-heading Finish -->

    <div class="panel-body"> <!--panel-body  begin -->
        <ul class="nav nav-pills nav-stacked category-menu"> <!--nav nav-pills nav-stacked category-menu  begin -->
            <!-- <li><a href="#">Man</a></li>
            <li><a href="#">Woman</a></li>
            <li><a href="#">Kids</a></li>
            <li><a href="#">Others</a></li> -->
            <?php
                get_Cats();
            ?>
        </ul><!-- nav nav-pills nav-stacked category-menu Finish -->
    </div><!-- panel-body Finish -->
</div><!-- panel panel-default sidebar-menu Finish -->