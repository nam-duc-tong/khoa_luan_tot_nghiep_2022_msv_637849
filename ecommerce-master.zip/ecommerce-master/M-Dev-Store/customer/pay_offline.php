<center>
    <h1>
        Pay Offline Using Method
    </h1>
    <p class="text-muted">
        if you have any questions, feel free to <a href="../contact.php">Contact us</a>.Our Customer Service work <strong>24/7</strong> 
    </p>
</center>
<hr>
<div class="table-reponsive">
    <table class="table table-bordered table-hover table-striped">
        <head>
            <tr>
               <th> Your Bank Account Details: </th>
               <th> Your Phone Number: </th>
               <th> Your Address: </th>
            </tr>
        </head>
        <tbody>
            <td> Bank Name: Vietinbank | Account Number: 01234556789</td>
            <td> 06834789531</td>
            <td> Viet Nam</td>
        </tbody>
    </table>
</div>