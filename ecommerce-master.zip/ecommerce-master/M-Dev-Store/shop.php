<?php
    $active='shop';
    include("includes/header.php");
?>
<style>
    .img-a{
        overflow: hidden;
        display: inline-block;
    }
    .img-a img {
        transition: 0.8s;
    }
    .img-a:hover img {
        transform: scale(1.2, 1.2);
    }
</style>
   <div id="content"><!-- content begin -->
       <div class="container"><!-- container begin -->
           <div class="col-sm-12"><!--col-md-12  begin -->
                <ul class="breadcrumb"><!-- breadcrumb begin -->
                    <li>
                        <a href="index.php">Trang Chủ</a>
                    </li>
                    <li>
                        Cửa Hàng
                    </li>
                </ul>
           </div><!-- col-md-12  Finish -->
           <div class="col-md-3"> <!-- col-md-3 begin -->            
            <?php
                include("includes/sidebar.php");
            ?>
           </div><!-- col-md-3 finish -->
            <div class="col-md-9">
                <?php
                if(!isset($_GET['p_cat']))
                {
                    if(!isset($_GET['cat']))
                    {
                        echo "  <div class='box'>
                                    <h1>Cửa Hàng</h1>
                                    <p>Những sản phẩm này đều là những sản phẩm chất lượng nhất và đẹp nhất</p>
                                </div>";
                    }
                }
                    
                ?>
                <div class="row">

                    <?php
                        if(!isset($_GET['p_cat']))
                        {
                            if(!isset($_GET['cat']))
                            {
                                $per_page = 6; // so luong san pham trong 1 trang
                                    if(isset($_GET['page']))
                                    {
                                        $page = $_GET['page'];
                                    }
                                    else{
                                        $page=1;
                                    }
                                        $start_from = ($page-1) * $per_page;
                                        $get_products = "select * from product order by 1 DESC LIMIT $start_from,$per_page";
                                        $run_products = mysqli_query($con,$get_products);
                                        while($row_products = mysqli_fetch_array($run_products))
                                        {
                                            $pro_id = $row_products['product_id'];

                                            $pro_title = $row_products['product_title'];
                                
                                            $pro_price = $row_products['product_price'];
                                
                                            $pro_img1 = $row_products['product_img1'];

                                            echo "
                                                <div class='col-md-4 col-sm-6 center-responsive'>
                                                    <div class='product'>
                                                        <a class='img-a' href='details.php?pro_id=$pro_id'>
                                                            <img class='img-responsive' src='admin_area/product_images/$pro_img1'>
                                                        </a>
                                                        <div class='text'>
                                                            <h3>
                                                                <a href='details.php?pro_id=$pro_id'>$pro_title</a>
                                                            </h3>
                                                            <p class='price'>
                                                                $pro_price VND
                                                            </p>
                                                            <p class='button'>
                                                                <a class='btn btn-default' href='details.php?pro_id=$pro_id'>
                                                                    Xem Chi Tiết
                                                                </a>
                                                                <a class='btn btn-primary' href='details.php?pro_id=$pro_id'>
                                                                <i class='fa fa-shopping-cart'></i> Thêm Vào Giỏ
                                                                </a>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            ";
                                        }
                    ?>

                </div> <!-- row finish -->

                <center>
                    <ul class="pagination">
                        <?php
                            $query = "select * from product";
                            
                            $result = mysqli_query($con,$query);

                            $total_records = mysqli_num_rows($result);

                            $total_pages = ceil($total_records/$per_page);
                            

                            echo "
                                    <li>
                                        <a href='shop.php?page=1'>".'Trang trước'."</a>
                                    </li>
                            ";
                            for($i=1;$i<=$total_pages;$i++)
                            {
                                echo "
                                    <li>
                                        <a href='shop.php?page=".$i."'>".$i."</a>
                                    </li>
                                ";
                            };
                            echo "
                                <li>
                                    <a href='shop.php?page=$total_pages'>".'Trang sau'."</a>
                                </li>
                            ";
                                 }
                            }
                        ?>
                        <!-- <li><a href="#">First Page</a></li>
                        <li><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li><a href="#">Last Page</a></li> -->
                    </ul>
                </center>
                <?php
                        getpCatpro();
                        getcatpro();
                    ?>
            </div><!-- col-md-9 finish -->
           
       </div><!-- container Finish -->

   </div><!-- content Finish -->

   <?php
        include("includes/footer.php");
    ?>
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
</body>
</html>